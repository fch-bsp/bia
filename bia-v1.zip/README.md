## Projeto base para o evento Bootcamp Imersão AWS que irei realizar.

### Período do evento: 02 a 08 de Outubro/2023 (Online e ao Vivo às 20h)

[>> Página de Inscrição do evento](https://org.imersaoaws.com.br/github/readme)

#### Para rodar as migrations no container ####
```
docker-compose exec server bash -c 'npx sequelize db:migrate'
```
